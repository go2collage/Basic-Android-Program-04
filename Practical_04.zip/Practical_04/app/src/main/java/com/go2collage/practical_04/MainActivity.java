package com.go2collage.practical_04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // declaring variables
    private TextView heading, para;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing variables
        heading = findViewById(R.id.txt1);
        para = findViewById(R.id.txt2);

        // set value to textView by using its ID
        heading.setText("About us");
        para.setText("go2collage is Technical Youtube Channel.");
    }
}